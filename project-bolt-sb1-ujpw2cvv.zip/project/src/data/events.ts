export const events = [
  {
    id: '1',
    title: 'Tech Innovation Summit 2024',
    description: 'Join industry leaders for a day of insights into the latest technology trends and innovations shaping our future.',
    date: '2024-04-15',
    time: '09:00 AM',
    location: 'Silicon Valley Convention Center',
    price: 299,
    capacity: 500,
    imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80',
    category: 'conference'
  },
  {
    id: '2',
    title: 'Digital Marketing Workshop',
    description: 'Learn practical strategies and tools to boost your digital marketing skills in this hands-on workshop.',
    date: '2024-04-20',
    time: '10:00 AM',
    location: 'Digital Hub Downtown',
    price: 149,
    capacity: 50,
    imageUrl: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80',
    category: 'workshop'
  },
  {
    id: '3',
    title: 'Leadership & Innovation Seminar',
    description: 'Discover how to foster innovation and lead teams effectively in the modern workplace.',
    date: '2024-04-25',
    time: '02:00 PM',
    location: 'Business Center Plaza',
    price: 199,
    capacity: 200,
    imageUrl: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&q=80',
    category: 'seminar'
  },
] as const;