export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  price: number;
  capacity: number;
  imageUrl: string;
  category: 'conference' | 'workshop' | 'seminar' | 'concert';
}

export interface BookingFormData {
  name: string;
  email: string;
  tickets: number;
}